import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
